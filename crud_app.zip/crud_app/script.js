document.addEventListener('DOMContentLoaded', function() {
    loadItems();

    const createForm = document.getElementById('create-form');
    if (createForm) {
        createForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const item = document.getElementById('item').value;
            fetch('backend/create.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ item: item })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'index.html';
                } else {
                    alert('Error creating item');
                }
            });
        });
    }

    const updateForm = document.getElementById('update-form');
    if (updateForm) {
        const urlParams = new URLSearchParams(window.location.search);
        const itemId = urlParams.get('id');
        document.getElementById('item-id').value = itemId;
        
        fetch(`backend/read.php?id=${itemId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('item').value = data.item.item;
                } else {
                    alert('Error loading item');
                }
            });

        updateForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const id = document.getElementById('item-id').value;
            const item = document.getElementById('item').value;
            fetch(`backend/update.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: id, item: item })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'index.html';
                } else {
                    alert('Error updating item');
                }
            });
        });
    }

    const confirmDelete = document.getElementById('confirm-delete');
    if (confirmDelete) {
        const urlParams = new URLSearchParams(window.location.search);
        const itemId = urlParams.get('id');
        
        confirmDelete.addEventListener('click', function() {
            fetch(`backend/delete.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: itemId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'index.html';
                } else {
                    alert('Error deleting item');
                }
            });
        });
    }
});

function loadItems() {
    fetch('backend/read.php')
    .then(response => response.json())
    .then(data => {
        const itemList = document.getElementById('item-list');
        itemList.innerHTML = '';
        data.items.forEach((item, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${item.item}</td>
                <td>
                    <a href="update.html?id=${item.id}" class="btn">Edit</a>
                    <a href="delete.html?id=${item.id}" class="btn">Delete</a>
                </td>
            `;
            itemList.appendChild(row);
        });
    });
}
