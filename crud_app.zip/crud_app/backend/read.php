<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare('SELECT * FROM items WHERE id = ?');
    $stmt->execute([$id]);
    $item = $stmt->fetch();
    if ($item) {
        echo json_encode(['success' => true, 'item' => $item]);
    } else {
        echo json_encode(['success' => false]);
    }
} else {
    $stmt = $pdo->query('SELECT * FROM items');
    $items = $stmt->fetchAll();
    echo json_encode(['success' => true, 'items' => $items]);
}
?>
