<?php
include 'db.php';

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['item'])) {
    $item = $data['item'];
    $stmt = $pdo->prepare('INSERT INTO items (item) VALUES (?)');
    if ($stmt->execute([$item])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
} else {
    echo json_encode(['success' => false]);
}
?>
