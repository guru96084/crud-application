<?php
include 'db.php';

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['id']) && isset($data['item'])) {
    $id = $data['id'];
    $item = $data['item'];
    $stmt = $pdo->prepare('UPDATE items SET item = ? WHERE id = ?');
    if ($stmt->execute([$item, $id])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
} else {
    echo json_encode(['success' => false]);
}
?>
